#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>       
#include <sys/ipc.h>      
#include <sys/shm.h>      
#include <sys/types.h>
#include <sys/wait.h>     

struct shared {
    char sel[100];   
    int b;           // Balance
};

int main() {
    int pipefd[2];           // pipefd[0]-reading, pipefd[1]-writing
    int shmid;               
    struct shared *data;    
    key_t key = ftok("shmfile", 65);  // unique key for shared memory

    // shared memory 
    shmid = shmget(key, sizeof(struct shared), 0666 | IPC_CREAT);
    data = (struct shared *) shmat(shmid, NULL, 0);  

    
    pipe(pipefd); //pipe for parent-child 

    printf("Provide Your Input From Given Options:\n");
    printf("1. Type a to Add Money\n");
    printf("2. Type w to Withdraw Money\n");
    printf("3. Type c to Check Balance\n\n");

    scanf("%s", data->sel);

    data->b = 1000;  //initial balance

    printf("\nYour selection: %s\n\n", data->sel);

    pid_t pid = fork(); //child process

    if (pid == 0) {

        if (strcmp(data->sel, "a") == 0) {
            int add_amt;   // Add money
            printf("Enter amount to be added:\n");
            scanf("%d", &add_amt);

            if (add_amt > 0) {
                data->b += add_amt;
                printf("Balance added successfully\n");
                printf("Updated balance after addition: %d\n\n", data->b);
            } else {
                printf("Adding failed, Invalid amount\n\n");
            }

        } else if (strcmp(data->sel, "w") == 0) {
            // Withdraw money
            int with_amt;
            printf("Enter amount to be withdrawn:\n");
            scanf("%d", &with_amt);

            if (with_amt > 0 && with_amt <= data->b) {
                data->b -= with_amt;
                printf("Balance withdrawn successfully\n");
                printf("Updated balance after withdrawal: %d\n\n", data->b);
            } else {
                printf("Withdrawal failed, Invalid amount\n\n");
            }

        } else if (strcmp(data->sel, "c") == 0) {
            
            printf("Your current balance is: %d\n\n", data->b);  // Check balance

        } else {
            
            printf("Invalid selection\n\n"); // Invalid typing
        }

       
        write(pipefd[1], "Thank you for using", 19);   // Send thank-you message 
        close(pipefd[1]); 
        exit(0);          

    } else {
        

        wait(NULL); // Wait for child to finish

        char buffer[100];
        read(pipefd[0], buffer, sizeof(buffer));  
        printf("%s\n", buffer);                   
        close(pipefd[0]);                         

       
        shmdt(data);              
        shmctl(shmid, IPC_RMID, NULL);  
    }

    return 0;
}
