#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h>

struct msg {
    long int type;     
    char txt[6];       // message content 
};

int main() {
    key_t key = ftok("msgfile", 65); // unique key
    int msgid = msgget(key, 0666 | IPC_CREAT); // message queue

    struct msg message;
    char input[20];

    // asks for workspace name
    printf("Please enter the workspace name:\n\n");
    scanf("%s", input);

    if (strcmp(input, "cse321") != 0) {
        printf("Invalid workspace name\n");
        msgctl(msgid, IPC_RMID, NULL); // Delete message queue
        return 0;
    }

    // Send workspace to OTP generator
    message.type = 1;
    strcpy(message.txt, input);
    msgsnd(msgid, &message, sizeof(message.txt), 0);
    printf("Workspace name sent to otp generator from log in: %s\n\n", message.txt);

    pid_t otp_pid = fork();

    if (otp_pid == 0) {
       
        msgrcv(msgid, &message, sizeof(message.txt), 1, 0);
        printf("OTP generator received workspace name from log in: %s\n\n", message.txt);

        // Generate OTP 
        pid_t otp = getpid();
        sprintf(message.txt, "%d", otp);

        
        message.type = 2;
        msgsnd(msgid, &message, sizeof(message.txt), 0);
        printf("OTP sent to log in from OTP generator: %s\n\n", message.txt);

        // OTP to mail 
        message.type = 3;
        msgsnd(msgid, &message, sizeof(message.txt), 0);
        printf("OTP sent to mail from OTP generator: %s\n\n", message.txt);

        // Fork mail process
        pid_t mail_pid = fork();
        if (mail_pid == 0) {
           
            msgrcv(msgid, &message, sizeof(message.txt), 3, 0);
            printf("Mail received OTP from OTP generator: %s\n\n", message.txt);

            // OTP to log in 
            message.type = 4;
            msgsnd(msgid, &message, sizeof(message.txt), 0);
            printf("OTP sent to log in from mail: %s\n\n", message.txt);

            exit(0); // mail ends
        } else {
            wait(NULL); // wait for mail
            exit(0);    // otp ends
        }

    } else {
       
        wait(NULL); // wait for otp and mail to finish

        msgrcv(msgid, &message, sizeof(message.txt), 2, 0);
        char otp1[6];
        strcpy(otp1, message.txt);
        printf("Log in received OTP from OTP generator: %s\n\n", otp1);

        msgrcv(msgid, &message, sizeof(message.txt), 4, 0);
        char otp2[6];
        strcpy(otp2, message.txt);
        printf("Log in received OTP from mail: %s\n\n", otp2);

        if (strcmp(otp1, otp2) == 0)
            printf("OTP Verified\n");
        else
            printf("OTP Incorrect\n");

        // Remove message queue
        msgctl(msgid, IPC_RMID, NULL);
    }

    return 0;
}
