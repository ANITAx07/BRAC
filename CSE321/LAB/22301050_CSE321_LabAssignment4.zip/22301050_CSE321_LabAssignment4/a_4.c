#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_USERS 5
#define MAX_RESOURCES 5
#define MAX_NAME_LEN 20

typedef enum {
    READ = 1,
    WRITE = 2,
    EXECUTE = 4
} Permission;

// User and Resource Definitions
typedef struct {
    char name[MAX_NAME_LEN];
} User;

typedef struct {
    char name[MAX_NAME_LEN];
} Resource;

// ACL Entry
typedef struct {
    char username[MAX_NAME_LEN];
    int permissions; // bitmask
} ACLEntry;

typedef struct {
    Resource resource;
    ACLEntry entries[MAX_USERS];
    int entryCount;
} ACLControlledResource;

// Capability Entry
typedef struct {
    char resourceName[MAX_NAME_LEN];
    int permissions;
} Capability;

typedef struct {
    User user;
    Capability capabilities[MAX_RESOURCES];
    int capabilityCount;
} CapabilityUser;

// Utility function 
void printPermissions(int perm) {
    if (perm & READ) printf("Read ");
    if (perm & WRITE) printf("Write ");
    if (perm & EXECUTE) printf("Execute ");
}

int hasPermission(int userPerm, int requiredPerm) {
    return (userPerm & requiredPerm) == requiredPerm;
}

// ACL System
void checkACLAccess(ACLControlledResource *res, const char *userName, int perm) {
    for (int i = 0; i < res->entryCount; i++) {
        if (!strcmp(res->entries[i].username, userName)) {
            printf("ACL Check: User %s requests ", userName);
            printPermissions(perm);
            printf("on %s: ", res->resource.name);
            if (hasPermission(res->entries[i].permissions, perm))
                printf("Access GRANTED\n");
            else
                printf("Access DENIED\n");
            return;
        }
    }
    printf("ACL Check: User %s has NO entry for resource %s: Access DENIED\n", userName, res->resource.name);
}

// Capability System
void checkCapabilityAccess(CapabilityUser *user, const char *resourceName, int perm) {
    for (int i = 0; i < user->capabilityCount; i++) {
        if (!strcmp(user->capabilities[i].resourceName, resourceName)) {
            printf("Capability Check: User %s requests ", user->user.name);
            printPermissions(perm);
            printf("on %s: ", resourceName);
            if (hasPermission(user->capabilities[i].permissions, perm))
                printf("Access GRANTED\n");
            else
                printf("Access DENIED\n");
            return;
        }
    }
    printf("Capability Check: User %s has NO capability for resource %s: Access DENIED\n", user->user.name, resourceName);
}

int main() {
    //Sample users and resources
      User users[MAX_USERS] = {{"Alice"}, {"Bob"}, {"Charlie"}, {"Dave"}, {"Eve"}};
      Resource resources[MAX_RESOURCES] = {{"File1"}, {"File2"}, {"File3"}, {"File4"}, {"File5"}};

    // ACL setup
    ACLControlledResource aclResources[MAX_RESOURCES];

    int r = 0;
    while (r < MAX_RESOURCES) {
        aclResources[r].resource = resources[r];
        aclResources[r].entryCount = 0;
        r++;
    }

    aclResources[0].entries[0] = (ACLEntry){"Alice", READ | WRITE};
    aclResources[0].entries[1] = (ACLEntry){"Bob", READ};
    aclResources[0].entryCount = 2;

    aclResources[1].entries[0] = (ACLEntry){"Charlie", EXECUTE};
    aclResources[1].entryCount = 1;

    aclResources[2].entries[0] = (ACLEntry){"Eve", READ | EXECUTE};
    aclResources[2].entryCount = 1;

    aclResources[3].entries[0] = (ACLEntry){"Dave", WRITE};
    aclResources[3].entryCount = 1;

    aclResources[4].entries[0] = (ACLEntry){"Alice", READ | EXECUTE};
    aclResources[4].entryCount = 1;

    // Capability setup
    CapabilityUser capabilityUsers[MAX_USERS];

    int u;
    for (u = 0; u < MAX_USERS; u++) {
        capabilityUsers[u].user = users[u];
        capabilityUsers[u].capabilityCount = 0;
    }

    capabilityUsers[0].capabilities[0] = (Capability){"File1", READ | WRITE};
    capabilityUsers[0].capabilities[1] = (Capability){"File5", READ | EXECUTE};
    capabilityUsers[0].capabilityCount = 2;

    capabilityUsers[1].capabilities[0] = (Capability){"File1", READ};
    capabilityUsers[1].capabilityCount = 1;

    capabilityUsers[2].capabilities[0] = (Capability){"File2", EXECUTE};
    capabilityUsers[2].capabilityCount = 1;

    capabilityUsers[3].capabilities[0] = (Capability){"File4", WRITE};
    capabilityUsers[3].capabilityCount = 1;

    capabilityUsers[4].capabilities[0] = (Capability){"File3", READ | EXECUTE};
    capabilityUsers[4].capabilityCount = 1;

    //  Test ACL
    checkACLAccess(&aclResources[0], "Alice", READ);
    checkACLAccess(&aclResources[0], "Bob", WRITE);
    checkACLAccess(&aclResources[1], "Charlie", EXECUTE);
    checkACLAccess(&aclResources[3], "Eve", WRITE);
    checkACLAccess(&aclResources[2], "Eve", EXECUTE);
    checkACLAccess(&aclResources[4], "Alice", EXECUTE);

    // Test Capability 
    checkCapabilityAccess(&capabilityUsers[0], "File1", WRITE);
    checkCapabilityAccess(&capabilityUsers[1], "File1", WRITE);
    checkCapabilityAccess(&capabilityUsers[2], "File2", EXECUTE);
    checkCapabilityAccess(&capabilityUsers[3], "File4", WRITE);
    checkCapabilityAccess(&capabilityUsers[4], "File3", READ);
    checkCapabilityAccess(&capabilityUsers[4], "File1", READ);

    return 0;
}

