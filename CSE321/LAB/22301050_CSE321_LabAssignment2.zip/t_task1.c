
#include <stdio.h>
#include <pthread.h>

#define MAX_SIZE 41
int Fibonacci_sequence[MAX_SIZE];
int n;

// Fibonacci sequence
void *generate_fibonacci_sequence(void *arg) {

    if (n >= 0) Fibonacci_sequence[0] = 0;
    if (n >= 1) Fibonacci_sequence[1] = 1;

    int i = 2;
    while (i <= n) {
          Fibonacci_sequence[i] = Fibonacci_sequence[i - 1] + Fibonacci_sequence[i - 2];
          i++;
    }


    pthread_exit(NULL);
}

int main() {
    pthread_t thread1;
    printf("Enter the term of Fibonacci sequence: ");
    scanf("%d", &n);

    if (n < 0 || n > 40) { 
        printf("n must be between 0 and 40.\n");
        return 1;
    }

    //generate Fibonacci sequence
    pthread_create(&thread1, NULL, generate_fibonacci_sequence, NULL);
    pthread_join(thread1, NULL); // Wait for pthread_create to complete

    int i;
    for (int i = 0; i <= n; i++) {
        printf("  a[%d] = %d\n", i, Fibonacci_sequence[i]);
    }

    // Search
    int search_count;
    printf("\nHow many numbers you are willing to search for? ");
    scanf("%d", &search_count);

    if (search_count <= 0) {
        printf(" You must search for at least one number.\n");
        return 1;
    }


    printf("\n Start entering indices to search:\n");
    i = 0;
    while (i < search_count) {
          int idx;
          printf("Enter search #%d: ", i + 1);
          scanf("%d", &idx);

          if (idx >= 0 && idx <= n) {
                 printf("Result of search #%d = %d\n", idx, Fibonacci_sequence[idx]);
          } else {
                  printf("Invalid index %d. Result = -1\n", idx);
          }
          i++;
}

    return 0;
}

