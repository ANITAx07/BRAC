#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#define MAX_STUDENTS 10
#define MAX_CHAIRS 3

sem_t student_ready;
sem_t tutor_ready[MAX_STUDENTS];
sem_t consultation_done;
pthread_mutex_t mutex;

int waiting_students = 0;
int served_students = 0;
int waiting_queue[MAX_CHAIRS];
int queue_front = 0;
int queue_back = 0;
int queue_count = 0;

void add_to_queue(int student_id) {
    waiting_queue[queue_back] = student_id;
    queue_back = (queue_back + 1) % MAX_CHAIRS;
    queue_count++;
}

int remove_from_queue() {
    int id = waiting_queue[queue_front];
    queue_front = (queue_front + 1) % MAX_CHAIRS;
    queue_count--;
    return id;
}

void* student_thread(void* arg) {
    int id = *((int*)arg);
    free(arg);

    int served = 0;
    while (!served) {
        pthread_mutex_lock(&mutex);
        if (waiting_students < MAX_CHAIRS) {
            printf("Student %d started waiting for consultation\n", id);
            add_to_queue(id);
            waiting_students++;
            pthread_mutex_unlock(&mutex);

            sem_post(&student_ready);    // Notify st
            sem_wait(&tutor_ready[id]);  // Wait till st calls 

            printf("Student %d is getting consultation\n", id);
            sleep(1); 

            printf("Student %d finished getting consultation and left\n", id);
            sem_post(&consultation_done);

            pthread_mutex_lock(&mutex);
            served_students++;
            printf("Number of served students: %d\n", served_students);
            pthread_mutex_unlock(&mutex);

            served = 1;
            
        } else {
            printf("No chairs remaining in lobby. Student %d Leaving...\n", id);
            pthread_mutex_unlock(&mutex);
            sleep(1);
        }
    }

    return NULL;
}

void* st_thread(void* arg) {
    while (1) {
        pthread_mutex_lock(&mutex);
        if (served_students >= MAX_STUDENTS) {
            pthread_mutex_unlock(&mutex);
            break;
        }
        pthread_mutex_unlock(&mutex);

        sem_wait(&student_ready);

        pthread_mutex_lock(&mutex);
        int student_id = remove_from_queue();
        waiting_students--;
        printf("A waiting student started getting consultation\n");
        printf("Number of students now waiting: %d\n", waiting_students);
        pthread_mutex_unlock(&mutex);

        printf("ST giving consultation\n");
        sem_post(&tutor_ready[student_id]);
        sem_wait(&consultation_done);
    }

    return NULL;
}

int main() {
    pthread_t tutor;
    pthread_t students[MAX_STUDENTS];

    sem_init(&student_ready, 0, 0);
    sem_init(&consultation_done, 0, 0);
    pthread_mutex_init(&mutex, NULL);
    for (int i = 0; i < MAX_STUDENTS; i++) {
        sem_init(&tutor_ready[i], 0, 0);
    }

    pthread_create(&tutor, NULL, st_thread, NULL);

    
    for (int i = 0; i < MAX_STUDENTS; i++) {
        int* id = malloc(sizeof(int));
        *id = i;
        pthread_create(&students[i], NULL, student_thread, id);
        usleep(100000);  //Pausefor 0.1 seconds 
    }

    for (int i = 0; i < MAX_STUDENTS; i++) {
        pthread_join(students[i], NULL);
    }

    pthread_join(tutor, NULL);

    sem_destroy(&student_ready);
    sem_destroy(&consultation_done);
    for (int i = 0; i < MAX_STUDENTS; i++) {
        sem_destroy(&tutor_ready[i]);
    }
    pthread_mutex_destroy(&mutex);

    return 0;
}
