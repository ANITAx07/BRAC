#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid1, pid2;

    pid1 = fork(); //child 

    if (pid1 < 0) {
        perror("Fork failed");
        exit(1);
    } else if (pid1 == 0) { // Child 
        pid2 = fork(); // grandchild 

        if (pid2 < 0) {
            perror("Fork failed");
            exit(1);
        } else if (pid2 == 0) { // Grandchild
            printf("I am grandchild\n");
            exit(0);
        } else { // Child process
            wait(NULL); // Wait for grandchild to finish
            printf("I am child\n");
            exit(0);
        }
    } else { // Parent 
        wait(NULL); // Wait for child to finish
        printf("I am parent\n");
    }

    return 0;
}



