#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    int fd;
    char filename[100], str[100];

    if (argc < 2) {
        printf("provide a filename as a command-line argument.\n");
        exit(1);
    }
    
    strcpy(filename, argv[1]);

    fd = open(filename, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (fd == -1) {
        perror("Unable to open file");
        exit(1);
    }

    printf("Enter a string to write to file or enter '-1' to quit:\n");
    scanf(" %[^\n]", str);

    while (strcmp(str, "-1") != 0) {
        write(fd, str, strlen(str));
        write(fd, "\n", 1);  

        printf("Enter another string or enter '-1' to quit:\n");
        scanf(" %[^\n]", str);
    }


    close(fd);

    printf("Above strings are written in %s file.\n", filename);

    return 0;
}

