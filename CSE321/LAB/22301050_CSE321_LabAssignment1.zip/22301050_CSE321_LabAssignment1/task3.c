#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>


int main() {
    int a, b, c;
    int count_process = 1;


    a = fork();
    b = fork();
    c = fork();


    if (a == 0) {
        if (getpid() % 2 != 0) {
            fork();
            count_process++;
        }
    } else if (b == 0) {
        if (getpid() % 2 != 0) {
            fork();
            count_process++;
        }
    } else if (c == 0) {
        if (getpid() % 2 != 0) {
            fork();
            count_process++;
        }
    } else {
        count_process += 3;


        printf("Total number of processes: %d\n", count_process);
    }


    return 0;
}

