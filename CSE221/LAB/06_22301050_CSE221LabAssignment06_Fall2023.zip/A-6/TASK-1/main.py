import math
import heapq
with open('E:\CSE221\A-6\TASK-1\input2.txt','r') as abc:
    f=open('E:\CSE221\A-6\TASK-1\output.txt','w')
    var=abc.readline().split(' ')
    # print(var)
    vertices=int(var[0])
    edge=int(var[1])
    
    adj_lst=[]  
    for j in range(vertices+1):
        adj_lst.append([])
    for i in range(edge):
        x,y,z=[int(i) for i in abc.readline().split(' ')]
        adj_lst[x].append([y,z])

    # print(adj_lst)
    #[[], [[2, 5], [3, 7], [4, 2]], [[4, 3], [5, 4]], [[5, 8]], [[3, 2]], [[4, 10]]]
    source=int(abc.readline()) #1
    visited=[0]*(vertices+1) #[0, 0, 0, 0, 0, 0, 0]
    distance=[math.inf]*(vertices) #[inf, inf, inf, inf, inf, inf]
    prioQ=[]
    
    for i in range(1,vertices+1):
        prioQ.append(i)
    heapq.heapify(prioQ)
    # print(prioQ)
    # print(distance)
    #[1, 2, 3, 4, 5, 6]
    def dijkstra(G,s): #s=1
        distance[s-1]=0  #[0, inf, inf, inf, inf, inf]
        visited[s]=1     #[0, 1, 0, 0, 0, 0, 0]
    
        while prioQ: #[  5, 6]
            u=heapq.heappop(prioQ)  # u=4
            # print(u)
            for i in G[u]:  #[3, 2]
                e=i[0] #3
                w=i[1] #2
                if visited[e] == 0: #e=3
                    visited[e] = 1  #[0, 1, 1, 1, 1, 1]
                
                if distance[u-1] + w < distance[e-1]: #2+2 < 7
                    distance[e-1]=distance[u-1] + w     #[0, 5, 4, 2, 9]
                    heapq.heappush(prioQ,e) #e=2-3-4
                 
        return distance
       
dijkstra(adj_lst,source)
print(distance)

for i in distance:
    if i == math.inf:
        f.write (f'{-1} ')  
    else:
        f.write(f'{i} ') 
